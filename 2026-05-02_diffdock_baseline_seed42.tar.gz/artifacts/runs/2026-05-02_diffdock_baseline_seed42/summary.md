# Baseline MVP Dry Run

- Dataset: pdbbind
- Split: smoke
- Complexes: 1
- Generation backend: diffdock
- Generated samples: 1
